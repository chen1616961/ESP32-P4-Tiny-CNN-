#!/usr/bin/env python3
"""Sample ESP32-P4 /api/status latency metrics and report p95.

Example:
    python tools/sample_status_latency.py 192.168.4.1 --duration-min 1 --interval-ms 200 --method tinycls --wake --set-interval-zero
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class Sample:
    index: int
    elapsed_ms: int
    request_ms: int
    ok: bool
    method: str = ""
    power_mode: str = ""
    network_mode: str = ""
    label: str = ""
    object_name: str = ""
    model: str = ""
    analysis_ms: int | None = None
    inference_ms: int | None = None
    inference_fps: float | None = None
    capture_fps: float | None = None
    stream_fps: float | None = None
    error: str = ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Sample board /api/status every N ms and compute analysis_ms p95."
    )
    parser.add_argument(
        "board",
        help="Board host or base URL, for example 192.168.4.1 or http://192.168.4.1",
    )
    parser.add_argument(
        "--duration-min",
        type=float,
        default=1.0,
        help="Sampling duration in minutes. Recommended range: 1 to 5. Default: 1",
    )
    parser.add_argument(
        "--interval-ms",
        type=int,
        default=200,
        help="Sampling interval in milliseconds. Default: 200",
    )
    parser.add_argument(
        "--timeout-s",
        type=float,
        default=2.0,
        help="HTTP timeout per request in seconds. Default: 2",
    )
    parser.add_argument(
        "--method",
        default="",
        help="Optional recognition method to set before sampling, for example tinycls.",
    )
    parser.add_argument(
        "--wake",
        action="store_true",
        help="Call /api/power?cmd=wake before sampling.",
    )
    parser.add_argument(
        "--set-interval-zero",
        action="store_true",
        help="Call /api/config?inference_interval_ms=0 before sampling.",
    )
    parser.add_argument(
        "--output",
        default="reports/status_latency_samples.csv",
        help="CSV output path. Default: reports/status_latency_samples.csv",
    )
    return parser.parse_args()


def normalize_base_url(text: str) -> str:
    if not text.startswith(("http://", "https://")):
        text = "http://" + text
    parsed = urllib.parse.urlparse(text)
    if not parsed.netloc:
        raise ValueError(f"bad board URL: {text}")
    return f"{parsed.scheme}://{parsed.netloc}"


def get_json(url: str, timeout_s: float) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"Cache-Control": "no-store"})
    with urllib.request.urlopen(req, timeout=timeout_s) as response:
        body = response.read()
    return json.loads(body.decode("utf-8"))


def call_endpoint(base_url: str, path: str, timeout_s: float) -> None:
    url = base_url + path
    req = urllib.request.Request(url, headers={"Cache-Control": "no-store"})
    with urllib.request.urlopen(req, timeout=timeout_s) as response:
        response.read()


def percentile(values: list[int], pct: float) -> int | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = math.ceil((pct / 100.0) * len(ordered)) - 1
    rank = max(0, min(rank, len(ordered) - 1))
    return ordered[rank]


def mean(values: list[int]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


def sample_status(base_url: str, args: argparse.Namespace) -> list[Sample]:
    duration_s = args.duration_min * 60.0
    interval_s = args.interval_ms / 1000.0
    samples: list[Sample] = []
    start = time.monotonic()
    next_at = start
    index = 0

    while True:
        now = time.monotonic()
        if now - start >= duration_s:
            break
        if now < next_at:
            time.sleep(next_at - now)

        index += 1
        elapsed_ms = int((time.monotonic() - start) * 1000)
        request_start = time.monotonic()
        url = base_url + f"/api/status?ts={int(time.time() * 1000)}"
        try:
            data = get_json(url, args.timeout_s)
            request_ms = int((time.monotonic() - request_start) * 1000)
            vision = data.get("vision") or {}
            samples.append(
                Sample(
                    index=index,
                    elapsed_ms=elapsed_ms,
                    request_ms=request_ms,
                    ok=True,
                    method=str(data.get("recognition_method") or ""),
                    power_mode=str(data.get("power_mode") or ""),
                    network_mode=str(data.get("network_mode") or ""),
                    label=str(vision.get("label") or ""),
                    object_name=str(vision.get("object") or ""),
                    model=str(vision.get("model") or ""),
                    analysis_ms=as_int(vision.get("analysis_ms")),
                    inference_ms=as_int(vision.get("inference_ms")),
                    inference_fps=as_x100(data.get("inference_fps_x100")),
                    capture_fps=as_x100(data.get("capture_fps_x100")),
                    stream_fps=as_x100(data.get("stream_fps_x100")),
                )
            )
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError) as exc:
            request_ms = int((time.monotonic() - request_start) * 1000)
            samples.append(
                Sample(
                    index=index,
                    elapsed_ms=elapsed_ms,
                    request_ms=request_ms,
                    ok=False,
                    error=str(exc),
                )
            )

        next_at += interval_s

    return samples


def as_int(value: Any) -> int | None:
    try:
        if value is None:
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def as_x100(value: Any) -> float | None:
    raw = as_int(value)
    if raw is None:
        return None
    return raw / 100.0


def write_csv(path: Path, samples: list[Sample]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "index",
                "elapsed_ms",
                "request_ms",
                "ok",
                "method",
                "power_mode",
                "network_mode",
                "label",
                "object",
                "model",
                "analysis_ms",
                "inference_ms",
                "inference_fps",
                "capture_fps",
                "stream_fps",
                "error",
            ],
        )
        writer.writeheader()
        for s in samples:
            writer.writerow(
                {
                    "index": s.index,
                    "elapsed_ms": s.elapsed_ms,
                    "request_ms": s.request_ms,
                    "ok": int(s.ok),
                    "method": s.method,
                    "power_mode": s.power_mode,
                    "network_mode": s.network_mode,
                    "label": s.label,
                    "object": s.object_name,
                    "model": s.model,
                    "analysis_ms": "" if s.analysis_ms is None else s.analysis_ms,
                    "inference_ms": "" if s.inference_ms is None else s.inference_ms,
                    "inference_fps": "" if s.inference_fps is None else f"{s.inference_fps:.2f}",
                    "capture_fps": "" if s.capture_fps is None else f"{s.capture_fps:.2f}",
                    "stream_fps": "" if s.stream_fps is None else f"{s.stream_fps:.2f}",
                    "error": s.error,
                }
            )


def fmt_ms(value: int | float | None) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:.1f} ms"
    return f"{value} ms"


def fmt_float(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{value:.2f}"


def print_summary(samples: list[Sample], output: Path) -> None:
    ok_samples = [s for s in samples if s.ok]
    analysis = [s.analysis_ms for s in ok_samples if s.analysis_ms is not None and s.analysis_ms > 0]
    inference = [s.inference_ms for s in ok_samples if s.inference_ms is not None and s.inference_ms > 0]
    request = [s.request_ms for s in samples if s.request_ms >= 0]
    fps_values = [s.inference_fps for s in ok_samples if s.inference_fps is not None and s.inference_fps > 0]
    latest = ok_samples[-1] if ok_samples else None

    print("\n=== /api/status latency summary ===")
    print(f"samples: total={len(samples)} ok={len(ok_samples)} errors={len(samples) - len(ok_samples)}")
    print(f"latest: method={latest.method if latest else 'n/a'} power={latest.power_mode if latest else 'n/a'} "
          f"label={latest.label if latest else 'n/a'} model={latest.model if latest else 'n/a'}")
    print(f"analysis_ms: avg={fmt_ms(mean(analysis))} p50={fmt_ms(percentile(analysis, 50))} "
          f"p95={fmt_ms(percentile(analysis, 95))} p99={fmt_ms(percentile(analysis, 99))} "
          f"max={fmt_ms(max(analysis) if analysis else None)}")
    print(f"inference_ms: avg={fmt_ms(mean(inference))} p95={fmt_ms(percentile(inference, 95))} "
          f"max={fmt_ms(max(inference) if inference else None)}")
    print(f"http_request_ms: avg={fmt_ms(mean(request))} p95={fmt_ms(percentile(request, 95))} "
          f"max={fmt_ms(max(request) if request else None)}")
    print(f"inference_fps: avg={fmt_float(sum(fps_values) / len(fps_values) if fps_values else None)} "
          f"latest={fmt_float(latest.inference_fps if latest else None)}")
    print(f"target check: p95_analysis<200ms => {percentile(analysis, 95) is not None and percentile(analysis, 95) < 200}")
    print(f"target check: latest_inference_fps>=5 => {latest is not None and latest.inference_fps is not None and latest.inference_fps >= 5.0}")
    print(f"csv: {output}")


def main() -> int:
    args = parse_args()
    if args.duration_min <= 0 or args.duration_min > 5:
        print("--duration-min must be > 0 and <= 5", file=sys.stderr)
        return 2
    if args.interval_ms <= 0:
        print("--interval-ms must be > 0", file=sys.stderr)
        return 2

    base_url = normalize_base_url(args.board)
    if args.wake:
        call_endpoint(base_url, "/api/power?cmd=wake", args.timeout_s)
        time.sleep(1.0)
    if args.method:
        method = urllib.parse.quote(args.method)
        call_endpoint(base_url, f"/api/recognition?method={method}", args.timeout_s)
        time.sleep(0.2)
    if args.set_interval_zero:
        call_endpoint(base_url, "/api/config?inference_interval_ms=0", args.timeout_s)
        time.sleep(0.2)

    print(
        f"Sampling {base_url}/api/status for {args.duration_min:g} min "
        f"every {args.interval_ms} ms..."
    )
    samples = sample_status(base_url, args)
    output = Path(args.output)
    write_csv(output, samples)
    print_summary(samples, output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
